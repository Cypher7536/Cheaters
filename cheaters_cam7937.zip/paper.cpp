//paper.cpp
//This file contains the implementations of the functions from the header file

#include "paper.h"
#include <bits/stdc++.h>
using namespace std;

Paper::Paper(){
   filepath = "";
   filename = "";  
}

Paper::Paper(string _filepath, string _filename){
   filepath = _filepath;
   filename = _filename;
}

string Paper::getFileName() const{
   return filename;
}

string Paper::getFilePath() const{
   return filepath + "/" + filename;
}

bool Paper::isChunksEmpty() const{
   return chunks.empty();
}

bool Paper::findChunks(int chunkSize){
   vector<string> queue;
   fstream file;
   string input;
   string chunk;

   
   //Opens file with the file path held in the object then
   //fills the queue with all the words in the file.
   file.open((*this).getFilePath().c_str());
   
   while(file >> input){
      queue.push_back(input);
   }

   //The plus 1 is to make sure that every word is indexed through.
   for(int i = 0; i < queue.size() - chunkSize + 1; i++){
      chunk = "";
      //Adds the amounts of words specified per chunk to the chunk string.
      for(int j = 0; j < chunkSize; j++){
         chunk = chunk + queue[i+j];
      }

      chunk = scrubChunk(chunk);
      chunks.push_back(chunk);
   }
   return true;
}

string Paper::scrubChunk(string chunk){
   int i = 0;

   //A while loop is used instead of a for loop to allow more control
   //over the index of i becuase if a character is removed from the
   //string I do not want to increase i to keep from skipping characters.
   while(i < chunk.length()){

      //Checkomg if it is a capitalized latter already
      if(((chunk[i]) >= 65) && ((chunk[i]) <= 90)){
         i = i + 1;
      }

      //Checking if it is a lowercase letter and capitalizing it.
      else if(((chunk[i]) >= 97) && ((chunk[i]) <= 122)){
         chunk[i] = chunk[i] - 32;
         i = i + 1;
      }
      
      //Removes the charater if not a upper or lowercase letter
      else{
         chunk.erase(chunk.begin() + i);
      }
   }
   return chunk;
}

string Paper::getChunk(){
   string temp = chunks.at(0);
   chunks.erase(chunks.begin());
   return temp;
}

void Paper::setFileName(string _filename){
   filename = _filename;
}

void Paper::setFilePath(string _filepath){
   filepath = _filepath;
}

bool Paper::operator>(const Paper &other) const{
   if(filename > other.filename)
      return true;
   else 
      return false;
}

bool Paper::operator<(const Paper &other) const{
   if(filename < other.filename)
      return true;
   else
      return false;
}

bool Paper::operator==(const Paper &other) const{
   if(filename == other.filename)
      return true;
   else
      return false;
}

