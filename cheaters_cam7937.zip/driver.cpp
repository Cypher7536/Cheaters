//cheaters_driver.cpp
//This file is the dirver file and handles the checking for plagerists.

//#include "paper.h"
#include "hash312.h"
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>

//using namespace std;

int getdir(string dir, vector<string> &files);

int main(int argc, char *argv[]){
   string filepath = (string) argv[1];
   
   //Converts console inputs to ints stoi would not work I have no idea why
   string temp = (string) argv[2];
   stringstream stoiWorkAround(temp);
   int chunkSize;
   stoiWorkAround >> chunkSize;
   temp = (string) argv[3];
   stringstream stoiWorkAround2(temp);
   int threshold ;
   stoiWorkAround2 >> threshold;
   vector<string> filenames;
  
   hash312 *cheaterChecker = new hash312;


   getdir(filepath, filenames);
   Paper tempP;
   tempP.setFilePath(filepath);

   for(int i = 0; i < filenames.size(); i++){
      if((!(filenames[i] == ".")) && (!(filenames[i] == ".."))){
         tempP.setFileName(filenames[i]);
         (*cheaterChecker).addPaper(tempP);
      }
   }

   (*cheaterChecker).populateHashTable(chunkSize);
   (*cheaterChecker).findMatches();
   (*cheaterChecker).printMatches(threshold);

   delete(cheaterChecker);
  
   return 0;
}

int getdir(string dir, vector<string> &files){
   DIR *dp;
   struct dirent *dirp;
   if((dp = opendir(dir.c_str())) == NULL){
      cout << "ERROR(" << errno << ") opening " << dir << endl;
      return errno;
   }

   while((dirp = readdir(dp)) != NULL){
      files.push_back(string(dirp->d_name));
   }

   closedir(dp);
   return 0;
}


