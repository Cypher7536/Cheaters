//hash2.h
//The Hash class handles the calling of the hashing of the 
//chunks within the papers and the actual comparisons.

#ifndef HASH312_H
#define HASH312_H

#include "paper.h"
#include <list>
#include <string>
#include <stdint.h>
#include <vector>
#include <iostream>
#include <iterator>

using namespace std;

//Number of files is set to 1000  by default if more files are neede please increase this value to match the amount of files.
//const int NUM_FILES = 1000;
//const int HASH_TABLE_SIZE = 1000003;

class hash312{ 

   public:

      hash312();

      //Adds a paper into the papers list.
      //Preconditions: The paper being added should already have had findchunks called, the paper
      //has a valid filename and filepath.
      //Postconditions: The paper will be added into the papers list
      //Input: a Paper to be added
      //Output: None
      void addPaper(const Paper &paper);
      
      //This function hashes all the papers currently in the paper list.
      //Precondtions: The papers have not haid their chunks created and have valid filenames and filepaths.
      //Postconditions: The hash table will be full of the filenames, collisions will be handled will linked lists.
      //Input: int size of chunks
      //Output: None
      void populateHashTable(int chunkSize);

      //This function checks for collisions within the hash table and adds 
      //them to the 2D to track how many similarites there are in the papers.
      //Preconditions: The populate hash table should be called prior to calling this function.
      //NOTE: It is essential that the papers to be sorted before this function is called
      //Postconditions: The 2D array will be filled with all chunk matches found between files.
      //Input: None
      //Output: None
      void findMatches();

      //This function prints out the filenames that have the same or higher amount of matches than the passed int.
      //Preconditions: The findMatches function has been successfully called.
      //Postconditions: All files that meet the parameters will be printed to the console.
      //Input: int of how many matchs a file needs to be printed.
      //Output: None
      void printMatches(int matchCount);

   private:
      //Number of files is set to 1000  by default if more files are neede please increase this value to match the amount of files.
      static const int NUM_FILES = 1000;
      static const int HASH_TABLE_SIZE = 1000003;


      //This function sorts the vector of papers using insertion sort. It is called by addPaper.
      //Preconditions: The list should always be sorted before a new paper is added, There are no more tha 1000 papers to be added.
      //Postcondtions: The 2D array of paper objects is sorted.
      //Input: New Paper to be add      //Output: None
//      void sortPapers(Paper &paper);//Probably will not need
   
      //This function is responsible for finding the index to put the chunk into the hash table.
      //Preconditions: The chunk is a valid string only consiting of uppercase letters.
      //Postcondtions: The filename that the chunk is within will be added to the hash table.
      //Input: string to be hashed, string of filename to be inputted into the hash table
      //Output: None
      int hashFunction(string chunk);

      vector<int> hashTable[HASH_TABLE_SIZE];
      list<Paper> papers;
      int matches[NUM_FILES][NUM_FILES];

     
};

class result{

   public:
   
      result();

      void setData(int _numMatches, string _fileOne, string _fileTwo);

      void printData();

      bool operator >(const result & other);

      bool operator <(const result & other);

      bool operator ==(const result & other);

   private:

      int numMatches;
      string fileOne;
      string fileTwo;
      
};

#endif

