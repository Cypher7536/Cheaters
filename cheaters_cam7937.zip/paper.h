//paper.h 
//This file contains the class header for the Paper
//class. The file class is responsible for storing and
//creating all relevant information for finding plagerists.


#ifndef PAPER_H
#define PAPER_H

#include <string>
#include <vector>

using namespace std;

class Paper {

   public:
     
      //Default constructor
      Paper();

      //Overloaded constructor that takes in the name of the file and the path to it
      Paper(string _filepath, string _filename);
      
      //This function finds all the chunks of the given size and stores them
      //into the chunks vector after scrubing the words in the chunk.
      //Preconditions: The chunk vector is empty, the size of the chunks is smaller than
      //the amount of words in the paper, a valid file path and filename has been provided.
      //Postcondition: The chunks vector will be full with all the chunks of the int size passed.
      //Input: size of the individual chunks
      //Output: true or false indicating failure or success
      bool findChunks(int chunkSize);

      //Returns the filename of the object.
      //Preconditions: A filename has been given.
      //Postconditions: None.
      //Input: None
      //Output: Name of the file as a string
      string getFileName() const;

      //Returns the full filepath of the paper.
      //Preconditions: A filepath and a filename has been given.
      //Postconditions: None.
      //Input: None
      //Output: Filepath as a string
      string getFilePath() const;
 
      //Returns whether the chunks vector is empty or not.
      //Preconditions: None.
      //Postconditions: None.
      //Input: None
      //Output: true or false depending on if the chunks vector is empty
      bool isChunksEmpty() const;

      //Returns the first chunk in the chunks vector and removes it.
      //Preconditions: The chunks vector is not empty.
      //Postconditions: The returned chunk will be removed from the vector.
      //Input: None
      //Output: The first chunk as a string of the vector
      string getChunk();

      //Sets the filename to the given parameter.
      //Preconditions: None.
      //Postconditions: None.
      //Input: string filename to be set to 
      //Output: None
      void setFileName(string _filename);

      //Sets the filepath to the gicen parameter.
      //Preconditions: None. 
      //Postconditions: None.
      //Input: string filepath to be set to
      //Output: None
      void setFilePath(string _filepath);

      //Returns true if the current object is larger than the one passed in based off of the filename.
      //Preconditions: The filename has been set for both objects.
      //Postconditions: None.
      //Input: Paper object to be compared
      //Output: bool true or false
      bool operator > (const Paper &other) const;

      //Returns true if the current object is smaller than the one passed in based off of the filename.
      //Preconditions: The filename has been set for both objects.
      //Postconditions: None.
      //Input: Paper object to be compared
      //Output: bool true or false
      bool operator < (const Paper &other) const;

      //Returns true if the current object is equal to the one passed in based off of the filename.
      //Preconditions: The filenmae has been set for both objects.
      //Postconditions: None.
      //Input: Paper object to be compared
      //Output: bool true or flase
      bool operator == (const Paper &other) const;

   private:

      //This function is called by the findChunks function and handles the scrubbing of the chunks.
      //Preconditions: None.
      //Postconditions: Given string will be scrubbed.
      //Input: string to be scrubbed
      //Output: string that is scrubbed
      string scrubChunk(string chunk);

      string filepath;
      string filename;

      vector <string> chunks;
};

#endif
