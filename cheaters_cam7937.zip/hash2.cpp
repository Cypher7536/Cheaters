//hash2.cpp
//This file holds the function implementations of the Hash class.

#include "hash2.h"
#include <iostream>

using namespace std;

hash312::hash312(){
   for(int i = 0; i < NUM_FILES; i++){
      for(int j = 0; j < NUM_FILES; j++){
         matches[i][j] = 0;
      }
   }
}

void hash312::addPaper(const Paper &paper){
   papers.push_back(paper);
}

void hash312::populateHashTable(int chunkSize){
   uint64_t hashValue;
   list<Paper>::iterator it = papers.begin();
   bool duplicate;

   papers.sort();
   for(int i = 0; i < papers.size(); i++){
      (*it).findChunks(chunkSize);
      // for(int j = 0; j < (*it).chunks.size(); j++){
      while(!(*it).isChunksEmpty()){
         hashValue = hashFunction((*it).getChunk());
         //Make sure the same paper does not have a chunk added more than once
         duplicate = false;

         for(int k = 0; k < hashTable[hashValue].size(); k++){
            if(hashTable[hashValue][k] == i){
               duplicate = true;
            }
         }
         
         if(!duplicate){
            hashTable[hashValue].push_back(i);
         }
      }
   advance(it, 1);
   }
//   advance(it, 1);

}

void hash312::findMatches(){

   for(int i = 0; i < HASH_TABLE_SIZE; i++){
      if(hashTable[i].size() > 1){
         for(int j = 0; j < hashTable[i].size(); j++){
            for(int k = j + 1; k < hashTable[i].size(); k++){
               if(hashTable[i][j] > hashTable[i][k]){
                  matches[hashTable[i][k]][hashTable[i][j]] = matches[hashTable[i][k]][hashTable[i][j]] + 1;
               }
               else{
                  matches[hashTable[i][j]][hashTable[i][k]] = matches[hashTable[i][j]][hashTable[i][k]] + 1;
               }
            }
         }
      }
   }
}

void hash312::printMatches(int matchCount){
   list<Paper>::iterator it1 = papers.begin();
   list<Paper>::iterator it2 = papers.begin();
   list<result> files;
   list<result>::iterator it3;
   result temp;

   for(int i = 0; i < NUM_FILES; i++){
      for(int j = 0; j < NUM_FILES; j++){
         
         it1 = papers.begin();
         it2 = papers.begin();
            if(matches[i][j] >= matchCount){
            advance(it1, i);
            advance(it2, j);
            temp.setData(matches[i][j], (*it1).getFileName(), (*it2).getFileName());
            files.push_back(temp);
         }
      }
   }
   files.sort();
   it3 = files.begin();
   
   for(int i = 0; i < files.size(); i++){
      (*it3).printData();
      advance(it3, 1);
   }
}

int hash312::hashFunction(string chunk){
   uint64_t hashValue = 0;
   const int p = 31;
   int power = 1;

   for(int i = 0; i < chunk.length(); i++){
      hashValue = (hashValue + (chunk[i] - 'A' + 1) * power) % HASH_TABLE_SIZE;
      power = (power * p) % HASH_TABLE_SIZE;
   }
   return hashValue;
}



/************************************************************/
//Start of the result class
//This class is only used in order to store file information and
//print out the results in the printMatches funtion

result::result(){
   numMatches = 0;
   fileOne = "";
   fileTwo = "";
}

void result::setData(int _numMatches, string _fileOne, string _fileTwo){
   numMatches = _numMatches;
   fileOne = _fileOne;
   fileTwo = _fileTwo;
}

void result::printData(){
   cout << numMatches << ": " << fileOne << ", " << fileTwo << endl;
}

//The sort of the list function sorts backward so the signs are flipped within the two sorts functions
bool result::operator >(const result & other){
   return numMatches < other.numMatches;
}

bool result::operator <(const result & other){
   return numMatches > other.numMatches;
}

bool result::operator ==(const result & other){
   return numMatches == other.numMatches;
}

